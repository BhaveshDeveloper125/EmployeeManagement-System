<h1>TrashedUser</h1>

<pre>
<?php echo e($users); ?>


<table border="1">
    <tr>
        <th>id</th>
        <th>name</th>
        <th>email</th>
        <th>Restore</th>
        <th>Delete</th>
    </tr>
    <tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($i->id); ?></th>
        <th><?php echo e($i->name); ?></th>
        <th><?php echo e($i->email); ?></th>
        <th> <a href="<?php echo e("/restore/{$i->id}"); ?>">Restore</a> </th>
        <th> <a href="<?php echo e($i->id); ?>">Delete</a> </th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
</table>

</pre><?php /**PATH D:\Project\GIt\EmployeeManagement-System\EmployeeManagement\resources\views/TrashedUsers.blade.php ENDPATH**/ ?>