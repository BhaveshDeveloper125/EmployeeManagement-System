<?php if(auth()->guard()->check()): ?>
<script>
    window.location.href = "/homepage/<?php echo e(Auth::user()->id); ?>";
</script>
<!-- <a href="/homepage/<?php echo e(Auth::user()->id); ?>">Home Page</a> -->
<?php endif; ?>


<?php if(auth()->guard()->guest()): ?>





<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <!--  -->


                    <p style="color: red;">Please Login for the further Process</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php endif; ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\GIt\EmployeeManagement-System\EmployeeManagement\resources\views\home.blade.php ENDPATH**/ ?>